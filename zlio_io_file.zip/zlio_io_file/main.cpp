#include "zlio.h"
#include "zlio.cpp"

int main(){
    out("This is the out command in zlio.h library\n");
    int input; 
    double finput;
    char sinput [128];

    in("Enter your input (integer): ", &input);

    out("%d\n", input);

    in("Enter your input (float): ", &finput);

    out("%f\n", finput);

    in("Enter your input (string): ", sinput);

    out("%s\n", sinput);

}