#include "zlio.h"
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdio.h>

void charoutput(char c) {
    write(STDOUT_FILENO, &c, 1);
}

void stroutput(const char *str, int *count) {
    if (!str) str = "(null)";
    while (*str) {
        charoutput(*str);
        if (count) (*count)++;
        str++;
    }
}

static void intoutput(int n, int *count) {
    char buf[32];
    int i = 0;

    if (n == 0) {
        charoutput('0');
        if (count) (*count)++;
        return;
    }

    long long num = n;
    if (num < 0) {
        charoutput('-');
        if (count) (*count)++;
        num = -num;
    }

    while (num > 0) {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }

    while (i > 0) {
        charoutput(buf[--i]);
        if (count) (*count)++;
    }
}

static void doubleoutput(double val, int *count) {
    char buf[64];
    snprintf(buf, sizeof(buf), "%f", val);
    stroutput(buf, count);
}

int out(const char *format, ...) {
    va_list args;
    va_start(args, format);
    int count = 0;

    while (*format) {
        if (*format == '%') {
            format++;

            if (*format == 'c') {
                char c = (char)va_arg(args, int);
                charoutput(c);
                count++;
            }
            else if (*format == 's') {
                char *s = va_arg(args, char *);
                stroutput(s, &count);
            }
            else if (*format == 'd' || *format == 'i') {
                int val = va_arg(args, int);
                intoutput(val, &count);
            }
            else if (*format == 'f') {
                double val = va_arg(args, double);
                doubleoutput(val, &count);
            }
            else if (*format == '%') {
                charoutput('%');
                count++;
            }
        } else {
            charoutput(*format);
            count++;
        }
        format++;
    }

    va_end(args);
    return count;
}

static void strw(const char *str) {
    if (str) {
        write(STDOUT_FILENO, str, strlen(str));
    }
}

static size_t rlen(char *buf, size_t max_len) {
    size_t i = 0;
    char c;
    while (i < max_len - 1) {
        ssize_t bytes = read(STDIN_FILENO, &c, 1);
        if (bytes <= 0 || c == '\n') break; 
        buf[i++] = c;
    }
    buf[i] = '\0';

    // Strip trailing carriage return '\r' and whitespace directly in rlen
    while (i > 0 && (buf[i - 1] == '\r' || isspace((unsigned char)buf[i - 1]))) {
        buf[--i] = '\0';
    }
    return i;
}

InputValue inraw(const char *prompt) {
    InputValue result;
    char buffer[256];

    strw(prompt);
    rlen(buffer, sizeof(buffer));

    if (buffer[0] == '\0') {
        result.type = INPUTSTR;
        result.data.stringvalue[0] = '\0';
        return result;
    }

    char *endptr;

    // First check if it contains a decimal point. If it does, prioritize DOUBLE!
    if (strchr(buffer, '.') != NULL) {
        double vald = strtod(buffer, &endptr);
        if (*endptr == '\0') {
            result.type = INPUTDOUBLE;
            result.data.doublevalue = vald;
            return result;
        }
    }

    // Try parsing as integer
    long vall = strtol(buffer, &endptr, 10);
    if (*endptr == '\0') {
        result.type = INPUTINT;
        result.data.intvalue = (int)vall;
        return result;
    }

    // Try standard double fallback
    double vald = strtod(buffer, &endptr);
    if (*endptr == '\0') {
        result.type = INPUTDOUBLE;
        result.data.doublevalue = vald;
        return result;
    }

    // Bool check
    if (strcasecmp(buffer, "true") == 0 || strcmp(buffer, "1") == 0 || strcasecmp(buffer, "yes") == 0) {
        result.type = INPUTBOOL;
        result.data.boolvalue = true;
        return result;
    }
    if (strcasecmp(buffer, "false") == 0 || strcmp(buffer, "0") == 0 || strcasecmp(buffer, "no") == 0) {
        result.type = INPUTBOOL;
        result.data.boolvalue = false;
        return result;
    }

    // Default to String
    result.type = INPUTSTR;
    strncpy(result.data.stringvalue, buffer, sizeof(result.data.stringvalue) - 1);
    result.data.stringvalue[sizeof(result.data.stringvalue) - 1] = '\0';

    return result;
}

void inint(const char *prompt, int *outval) {
    InputValue res = inraw(prompt);
    if (res.type == INPUTINT) *outval = res.data.intvalue;
    else if (res.type == INPUTDOUBLE) *outval = (int)res.data.doublevalue;
    else if (res.type == INPUTSTR) *outval = atoi(res.data.stringvalue);
    else *outval = 0;
}

void indouble(const char *prompt, double *outval) {
    InputValue res = inraw(prompt);
    if (res.type == INPUTDOUBLE) *outval = res.data.doublevalue;
    else if (res.type == INPUTINT) *outval = (double)res.data.intvalue;
    else if (res.type == INPUTSTR) *outval = atof(res.data.stringvalue);
    else *outval = 0.0;
}

void inbool(const char *prompt, bool *outval) {
    InputValue res = inraw(prompt);
    if (res.type == INPUTBOOL) *outval = res.data.boolvalue;
    else if (res.type == INPUTINT) *outval = res.data.intvalue != 0;
    else *outval = false;
}

void instr(const char *prompt, char *outval) {
    InputValue res = inraw(prompt);
    if (res.type == INPUTINT) {
        snprintf(outval, 256, "%d", res.data.intvalue);
    } else if (res.type == INPUTDOUBLE) {
        snprintf(outval, 256, "%f", res.data.doublevalue);
    } else if (res.type == INPUTBOOL) {
        strncpy(outval, res.data.boolvalue ? "true" : "false", 255);
        outval[255] = '\0';
    } else {
        strncpy(outval, res.data.stringvalue, 255);
        outval[255] = '\0';
    }
}